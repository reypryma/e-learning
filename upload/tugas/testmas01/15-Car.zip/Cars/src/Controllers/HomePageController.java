/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPopup;
import com.jfoenix.controls.JFXRippler;
import com.jfoenix.controls.JFXToolbar;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.util.Duration;

/**
 *
 * @author ATaha
 */
public class HomePageController implements Initializable {

    @FXML
    private AnchorPane holderPane;

    
    @FXML
    private Text welcome;
    @FXML
    private JFXToolbar toolbar;
    @FXML
    private HBox toolBarRight;
    @FXML
    private VBox overFlowContaner;
    @FXML
    private JFXButton btnLogOut;
    @FXML
    private JFXButton btnExit;

    private AnchorPane home;
    @FXML
    private Label lblMenu;
    @FXML
    private AnchorPane anchor;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        JFXRippler rippler = new JFXRippler(lblMenu);
        rippler.setMaskType(JFXRippler.RipplerMask.RECT);
        toolBarRight.getChildren().add(rippler);
        
        openMenu();
        createPage();
    }

    private void setNode(Node node) {

        holderPane.getChildren().clear();
        holderPane.getChildren().add((Node) node);

        FadeTransition ft = new FadeTransition(Duration.millis(1500));
        ft.setNode(node);
        ft.setFromValue(0.1);
        ft.setToValue(1);
        ft.setCycleCount(1);
        ft.setAutoReverse(false);
        ft.play();
    }

    private void createPage() {
        try {

            home = FXMLLoader.load(getClass().getResource("/FXML/Home.fxml"));
            setNode(home);
            
        } catch (Exception e) {

        }
    }

   private void openMenu() {
        JFXPopup pop = new JFXPopup();
        pop.setContent(overFlowContaner);
        pop.setPopupContainer(anchor);
       pop.setSource(lblMenu);
    
       
       lblMenu.setOnMouseClicked(e ->{
			
			pop.show(JFXPopup.PopupVPosition.TOP, JFXPopup.PopupHPosition.RIGHT, -1, 42);
			
		});
       
   }

}
