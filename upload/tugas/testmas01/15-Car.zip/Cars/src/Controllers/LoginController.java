/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import DBConnection.DBHandler;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.scene.control.Alert;

/**
 * FXML Controller class
 *
 * @author ATaha
 */
public class LoginController implements Initializable {

    @FXML
    private JFXTextField username;

    @FXML
    private JFXPasswordField password;

    @FXML
    private JFXButton signup;

    @FXML
    private JFXButton login;

    @FXML
    private JFXCheckBox remmnber;

    @FXML
    private JFXButton forgetpassword;

    @FXML
    private ImageView progress;

    private Connection connection;
    private DBHandler handler;
    private PreparedStatement pst;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        progress.setVisible(false);
        username.setStyle("-fx-text-inner-color :#a0a2ab");
        password.setStyle("-fx-text-inner-color :#a0a2ab");

        handler = new DBHandler();

    }

    @FXML
    public void loginAction(ActionEvent event) throws SQLException {
        progress.setVisible(true);
        PauseTransition pt = new PauseTransition();
        pt.setDuration(Duration.seconds(3));
        pt.setOnFinished(e -> {
            System.out.println("Login Sucsesfuly ....");
        });
        pt.play();
        //Login Dbase
        try {

            connection = handler.getConnection();
            String st = "select * from carusers where name = ? and password =? ";
            pst = connection.prepareStatement(st);
            pst.setString(1, username.getText());
            pst.setString(2, password.getText());
            ResultSet rs = pst.executeQuery();
            
            int count = 0;
            while(rs.next()){
                count = count +1;
                
            }
            if(count == 1){
                System.out.println("login is ok ");
                login.getScene().getWindow().hide();
                Stage home = new Stage();
                Parent root = FXMLLoader.load(getClass().getResource("/FXML/HomePage.fxml"));
                Scene scene = new Scene(root);
                home.setScene(scene);
                home.show();
                
                
            }else {
                System.out.println("Error username or password not correct");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText(" username or password not correct ...");
                alert.showAndWait();
                 progress.setVisible(false);
                
                
            }

        } catch (Exception e) {
        }
        finally{
            connection.close();
        }

    }

    @FXML
    public void sginupAction(ActionEvent event) {
        try {

            login.getScene().getWindow().hide();
            Stage signup = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("/FXML/SginUp.fxml"));
            Scene scene = new Scene(root);
            signup.setScene(scene);
            signup.show();
            signup.setResizable(false);

        } catch (Exception e) {
            System.out.println(" Error signup : " + e);
        }
    }

}
