/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ATaha
 */
public class DBHandler extends Configs {

    Connection dbConnection;

    public Connection getConnection() {
        // "jdbc:mysql://localhost:3306/invdbfx";
        String connectionString = "jdbc:mysql://" + Configs.dbhost + ":" + Configs.dbport + "/" + Configs.dbshima;
        try {

            Class.forName("com.mysql.jdbc.Driver");
            dbConnection = DriverManager.getConnection(connectionString, Configs.dbuser, Configs.dbpass);
        } catch (Exception e) {
        }

        return dbConnection;
    }

}
