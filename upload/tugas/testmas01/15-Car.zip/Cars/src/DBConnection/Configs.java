/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DBConnection;

/**
 *
 * @author ATaha
 */
public class Configs {
    protected static String dbhost = "localhost";
    protected static String dbport = "3306";
    protected static String dbuser = "root";
    protected static String dbpass = "ashraf";
    protected static String dbshima = "invdbfx";
    
}
