package DBConnection;

public class Configs {

	protected static String dbhost = "localhost";
	protected static String dbport = "3306";
	protected static String dbuser = "root";
	protected static String dbpass = "nilskadam700";
	protected static String dbname = "genius";
	
}
